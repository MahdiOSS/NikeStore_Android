package com.abolfazloskooii.nikeshop.Auth

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.FragmentTransaction.*
import com.abolfazloskooii.nikeshop.Base.Base
import com.abolfazloskooii.nikeshop.Base.CompletableNike
import com.abolfazloskooii.nikeshop.Base.threadNetWortRequest
import com.abolfazloskooii.nikeshop.R
import com.abolfazloskooii.nikeshop.Servies.error.NikeException
import com.abolfazloskooii.nikeshop.ViewModels.AuthViewModel
import io.reactivex.rxjava3.disposables.CompositeDisposable
import kotlinx.android.synthetic.main.fragment_login.*
import kotlinx.android.synthetic.main.fragment_login.emailEt
import kotlinx.android.synthetic.main.fragment_login.passwordEt
import kotlinx.android.synthetic.main.fragment_sign_up.*
import org.koin.androidx.viewmodel.ext.android.viewModel

class SignUpFragment : Base.NikeFragment() {

    private val viewModel: AuthViewModel by viewModel()
    private val compositeDisposable = CompositeDisposable()

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_sign_up,container,false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        viewModel.setProgress().observe(viewLifecycleOwner) {
            progress(it)
        }

        signUpBtn.setOnClickListener {
            if (passwordEt.text.isNotEmpty() && emailEt.text.isNotEmpty()) {
                if (passwordEt.text.toString() == passwordEtRepeat.text.toString()) {
                    if (passwordEt.text.length >= 6) {
                        viewModel.signup(passwordEt.text.toString(), emailEt.text.toString())
                            .threadNetWortRequest()
                            .subscribe(object : CompletableNike(compositeDisposable) {
                                override fun onComplete() {
                                    requireActivity().finish()
                                }
                            })
                    } else
                        showSnackBar(getString(R.string.Error1))
                } else
                    showSnackBar(getString(R.string.Error))
            }else
                showSnackBar(getString(R.string.Error1))

        }
        loginLinkBtn.setOnClickListener {
            requireActivity().supportFragmentManager.beginTransaction().apply {
                replace(R.id.FrameAuth, LoginFragment())
                    .setTransition(TRANSIT_FRAGMENT_FADE)
            }.commit()
        }
    }

    override fun onStop() {
        super.onStop()
        compositeDisposable.clear()
    }
}