package com.abolfazloskooii.nikeshop.Model.repositories.Manager

import com.abolfazloskooii.nikeshop.Model.Product
import io.reactivex.rxjava3.core.Completable
import io.reactivex.rxjava3.core.Single

interface ProductsRepositoryManager {

    fun getProducts(sort : Int): Single<List<Product>>

    fun getProductsFavorite() : Single<List<Product>>

    fun deleteFav(product: Product) : Completable

    fun addFav(product: Product) : Completable

}