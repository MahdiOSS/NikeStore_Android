package com.abolfazloskooii.nikeshop.Model

data class AddComment(
	val productId: Int? = null,
	val title: String? = null,
	val content: String? = null
)

