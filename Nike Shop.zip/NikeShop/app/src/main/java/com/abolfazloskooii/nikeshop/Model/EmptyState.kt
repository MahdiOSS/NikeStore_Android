package com.abolfazloskooii.nikeshop.Model

import androidx.annotation.StringRes

data class EmptyState(
    val show: Boolean,
    var message : Int = 0,
    val showBtn : Boolean = false
)
