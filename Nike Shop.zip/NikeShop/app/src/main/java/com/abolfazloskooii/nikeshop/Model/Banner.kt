package com.abolfazloskooii.nikeshop.Model

data class Banner(
	val linkType: Int? = null,
	val image: String? = null,
	val id: Int? = null,
	val linkValue: String? = null
)

