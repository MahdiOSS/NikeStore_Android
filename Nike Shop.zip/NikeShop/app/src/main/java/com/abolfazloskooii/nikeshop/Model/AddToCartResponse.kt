package com.abolfazloskooii.nikeshop.Model
//cart/add
data class AddToCartResponse(
    val count: Int,
    val id: Int,
    val product_id: Int
)