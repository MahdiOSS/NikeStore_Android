package com.abolfazloskooii.nikeshop.View.profile

import android.content.Intent
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.net.toUri
import com.abolfazloskooii.nikeshop.Auth.Auth
import com.abolfazloskooii.nikeshop.Base.Base
import com.abolfazloskooii.nikeshop.R
import com.abolfazloskooii.nikeshop.ViewModels.ProfileViewModel
import kotlinx.android.synthetic.main.fragment_profile.*
import kotlinx.android.synthetic.main.item_product.*
import org.koin.androidx.viewmodel.ext.android.viewModel
import timber.log.Timber
import java.io.File
import java.net.URI


class ProfileFragment : Base.NikeFragment() {
    val viewModel: ProfileViewModel by viewModel()
    private lateinit var selectImage : ActivityResultLauncher<String>
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fragment_profile, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        favoriteSection.setOnClickListener{
            startActivity(Intent(requireContext(),FavoriteActivity::class.java))
        }

        order_His.setOnClickListener {
            startActivity(Intent(requireContext(),OrderHistoryActivity::class.java))
        }

    }

    private fun check() {
        if (viewModel.signIn) {
            authBtn.text = getString(R.string.signOut)
            authBtn.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.ic_sign_out, 0)
            usernameTv.text = viewModel.username
            authBtn.setOnClickListener {
                viewModel.signOut()
                check()
            }
        } else {
            authBtn.text = getString(R.string.signIn)
            usernameTv.text = getString(R.string.guest_user)
            authBtn.setCompoundDrawablesWithIntrinsicBounds(0, 0, R.drawable.ic_sign_in, 0)
            authBtn.setOnClickListener {
                startActivity(Intent(requireContext(), Auth::class.java))
            }
        }
    }

    override fun onResume() {
        super.onResume()
        check()
    }
}