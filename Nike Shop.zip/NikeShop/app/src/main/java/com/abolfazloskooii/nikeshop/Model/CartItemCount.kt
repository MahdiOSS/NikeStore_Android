package com.abolfazloskooii.nikeshop.Model

data class CartItemCount(
    var count: Int
)