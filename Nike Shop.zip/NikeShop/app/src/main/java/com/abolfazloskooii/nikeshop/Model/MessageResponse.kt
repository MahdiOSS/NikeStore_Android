package com.abolfazloskooii.nikeshop.Model

data class MessageResponse(
    val message: String
)